import React from "react";
import EventHandling from "./EventHandling";

function App() {
  return (
    <div>
      <h1>🚀 React Event Handling Demo</h1>
      <EventHandling />
    </div>
  );
}

export default App;
