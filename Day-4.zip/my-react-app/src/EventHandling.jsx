import React from "react";

function EventHandling() {

  function handleClick() {
    alert("🎉 Button clicked! You triggered an event.");
  }

  return (
    <div>
      <p>Click the button to trigger an event:</p>
      <button onClick={handleClick}>Click Me</button>
    </div>
  );
}

export default EventHandling;
