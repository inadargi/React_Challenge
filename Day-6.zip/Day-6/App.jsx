
import Counter1 from "./Counter1";

function App() {
  return (
    <div>
  <h1>🚀 useState() in Action – React Counter</h1>
      <Counter1 />
    </div>
  );
}

export default App;
