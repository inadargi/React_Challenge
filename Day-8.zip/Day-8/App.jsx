import React, { useState } from 'react';
import ConditionalRenderer from './ConditionalRenderer';

function App() {
  return (
    <div>
      <h1>🚀 Day-8 React Conditional Rendering </h1>
      <ConditionalRenderer />
    </div>
  );
}

export default App;
