import React, { useState } from 'react';

function ConditionalRenderer() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  const toggleLogin = () => {
    setIsLoggedIn(!isLoggedIn);
  };

  const boxStyle = {
    width: '300px',
    margin: '100px auto',
    padding: '20px',
    borderRadius: '10px',
    boxShadow: '0 0 10px rgba(0,0,0,0.1)',
    textAlign: 'center',
    fontFamily: 'Arial, sans-serif',
  };

  const buttonStyle = {
    padding: '10px 20px',
    fontSize: '16px',
    borderRadius: '5px',
    border: 'none',
    backgroundColor: '#007bff',
    color: 'white',
    cursor: 'pointer',
  };

  return (
    <div style={boxStyle}>
      {isLoggedIn ? (
        <>
          <h2>👋 Welcome Back!</h2>
          <p>You are now logged in.</p>
          <button style={buttonStyle} onClick={toggleLogin}>Logout</button>
        </>
      ) : (
        <>
          <h2>🔒 Please Log In</h2>
          <p>You must be logged in to continue.</p>
          <button style={buttonStyle} onClick={toggleLogin}>Login</button>
        </>
      )}
    </div>
  );
}

export default ConditionalRenderer;
