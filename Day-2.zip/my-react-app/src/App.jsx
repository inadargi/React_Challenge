import Welcome from './Welcome';
function App() {
  return (
    <div>
      <Welcome/>
      <p>This is my second day learning React!</p>
    </div>
  );
}
export default App