function Welcome() {
  const name = "Isha Nadargi";
  return <h2>Welcome to React, {name}! 👋</h2>;
}
export default Welcome