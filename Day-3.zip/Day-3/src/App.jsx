import Props_ex from "./props_ex";

function App(){
  return(
    <>
    <Props_ex name="Isha Nadargi"/>
    <Props_ex name="React Learner"/>
    </>
  )
}
export default App