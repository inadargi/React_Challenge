function Props_ex({ name }) {
  return <h2>Hello, {name}! 👋</h2>;
}
export default Props_ex